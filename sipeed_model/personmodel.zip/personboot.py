import sensor,image,lcd,time
import KPU as kpu
lcd.init(freq=15000000)
sensor.reset(dual_buff=1)
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.set_hmirror(1)
sensor.set_vflip(0)
sensor.set_windowing((224, 224))


sensor.run(1)
clock = time.clock()
classes = ['person']
task = kpu.load(0x300000)
anchor = (0.76,1.98, 1.20,3.06, 1.51,4.30, 2.06,5.32, 2.87,6.02)
a = kpu.init_yolo2(task, 0.3, 0.3, 5, anchor)
while(True):
    clock.tick()
    img = sensor.snapshot()
    code = kpu.run_yolo2(task, img)
    print(clock.fps())
    fps =clock.fps()
    img.draw_string(2,2, ("%2.1ffps" %(fps)), color=(0,255,0), scale=2)
    if code:
        for i in code:
            a=img.draw_rectangle(i.rect())
            a = lcd.display(img)
            print(i.classid(),i.value())
            for i in code:
                lcd.draw_string(i.x(), i.y(), classes[i.classid()], lcd.RED, lcd.WHITE)
                lcd.draw_string(i.x(), i.y()+12, '%.2f'%i.value(), lcd.RED, lcd.WHITE)
    else:
        a = lcd.display(img)
a = kpu.deinit(task)
